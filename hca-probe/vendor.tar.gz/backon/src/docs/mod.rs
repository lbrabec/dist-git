//! Docs for the backon crate, like [`examples`].

pub mod examples;
