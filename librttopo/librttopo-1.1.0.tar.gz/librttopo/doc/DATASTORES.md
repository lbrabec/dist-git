List of known data stores for librttopo
=======================================

* spatialite 4.4.0
